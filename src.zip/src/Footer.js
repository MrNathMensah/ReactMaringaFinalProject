import React from 'react'
import './Footer.css';

function Footer() {
    return (
        <footer className="footer">
          <div className="footer-left">
            <img src="aiti.png" alt="Logo" className="footer-logo" />
            <ul className="footer-list">
              <li className="footer-list-item">Courses</li>
              <li className="footer-list-item">Careers</li>
              <li className="footer-list-item">FAQs</li>
              <li className="footer-list-item">Contact Us</li>
            </ul>
          </div>
          <div className="footer-right">
            <ul className="footer-list">
              <li className="footer-list-item">Ngong Lane, Ngong Lane Plaza</li>
              <li className="footer-list-item">1st Floor, Nairobi Kenya</li>
              <li className="footer-list-item">+233564747439 (Admissions/General Enquiries)</li>
              <li className="footer-list-item">+23367748493 (Data Science)</li>
            </ul>
          </div>
        </footer>
      );
    };

export default Footer