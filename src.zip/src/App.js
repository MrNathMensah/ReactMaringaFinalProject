import Footer from './Footer';
import Header from './Header';
import Projectbody1 from './Projectbody1';
import Projectbody2 from './Projectbody2';

function App() {
  return (
    <div>
      <Header/>
      <Projectbody1/>
      <Projectbody2/>
      <Footer/>
    </div>
  );
}

export default App;
